# Physician Adjudication — Instruction Sheet
## Study: "Compositional Reasoning Depth Predicts Clinical AI Failure"

**Purpose**: Validate the automated AI judge (gpt-4o-mini) used in this study against physician judgment. The AI judge scored each model response as correct or incorrect. You are being asked to independently score the same responses.

**Your task takes approximately 2–3 hours** for 100 cases. Cases are short clinical questions — most take under 2 minutes each.

---

## What You Will Receive

A spreadsheet (`physician_adjudication_sheet.csv`) with 100 rows. Each row is one AI model response to a clinical EHR question. For each case you will see:

| Column | Contents |
|---|---|
| `Clinical_Question` | The question posed to the AI model (same question a clinician might ask about a patient) |
| `Clinician_Reference_Answer` | The ground-truth answer written by a board-certified clinician who reviewed the actual patient EHR |
| `Model_Response` | The AI model's response |
| `AI_Judge_Correct_0or1` | What the automated judge decided (1 = correct, 0 = incorrect) |
| `AI_Judge_Error_Type` | The error type the judge assigned (none / omission / hallucination / reasoning_error) |
| `AI_Judge_Confidence_0to1` | The judge's confidence in its own scoring (0.80–1.00 range) |

**You do NOT have access to the original EHR.** Score based solely on whether the Model Response agrees with the Clinician Reference Answer.

---

## Scoring Instructions

### Column: `Physician_Correct_Y_N`
Enter **Y** or **N**.

- **Y (Correct)**: The model response substantially agrees with the clinician reference answer. Minor wording differences are fine. Partial answers that contain the core correct information count as correct.
- **N (Incorrect)**: The model response disagrees with, contradicts, or substantially omits the key content of the clinician reference answer.

**Do not penalize for:**
- Extra information not in the reference (unless factually wrong)
- Different phrasing or formatting
- Level of detail (terse vs. verbose)

**Do penalize for:**
- Wrong facts stated as correct
- Key omissions that would mislead a clinician
- Fabricated information not present in the reference

---

### Column: `Physician_Error_Type`
If you marked **N (incorrect)**, enter the primary error type:

| Code | Definition |
|---|---|
| `omission` | Model declined to answer, gave an empty response, said "I don't know," or gave an irrelevant response |
| `hallucination` | Model stated facts not present in the reference answer or inconsistent with standard medical knowledge |
| `reasoning_error` | Model had the right factual information but reached the wrong conclusion (e.g., correct labs, wrong interpretation) |

If you marked **Y (correct)**, enter `none`.

---

### Column: `Physician_Disagree_Reason`
**Fill in only when your judgment differs from the AI judge** (i.e., you say Y but AI said 0, or you say N but AI said 1). Brief free text, 1 sentence is enough.

Examples:
- "AI marked incorrect but the model gave the right answer — clinician reference was more detailed but core answer matches"
- "AI marked correct but model stated wrong medication name"

---

## Calibration Cases (first 5 cases)

Please review cases 1–5 first and compare your judgments with the answer key below before proceeding. These are calibration cases to align your scoring with the intended rubric.

*(Answer key will be provided separately by the study coordinator)*

---

## Important Notes

1. **You are blinded to the model condition** (whether the response came from zero-shot or extended-thinking inference). This is intentional.
2. **Score what the model said, not what a clinician should say.** The question is whether the model was right or wrong, not whether the answer is clinically complete enough to act on.
3. **When in doubt, mark N.** The study is designed to evaluate whether models fail; false negatives (marking a correct response as wrong) are less harmful than false positives for this validation purpose.
4. **Cases are randomized** — hop complexity varies throughout the sheet. You will not see them in order of difficulty.
5. **Independent scoring**: If 2 physicians are reviewing, do not discuss cases before completing your individual scoring sheet.

---

## Returning Your Completed Sheet

Return the completed CSV to the study coordinator. The analysis will compute:
- **Cohen's κ** between physician judgment and AI judge (primary validation metric)
- **Inter-physician κ** (if 2 reviewers)
- **Calibration by hop level** and by judge confidence stratum

Target: κ ≥ 0.70 (substantial agreement) to validate the AI judge for use in the primary analysis.

---

## Contact

Questions: contact the study PI.

---

*This adjudication involves de-identified, publicly available EHR data (MedAlign / Stanford STARR-OMOP, released under the MedAlign data use agreement). No new patient data is collected. This activity constitutes professional quality assessment and is not classified as human subjects research.*
